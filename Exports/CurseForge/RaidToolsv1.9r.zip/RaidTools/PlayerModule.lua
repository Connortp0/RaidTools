-- Create a frame for your menu
local myMenuFrame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
myMenuFrame:SetSize(135, 155) -- Adjust the height as needed
myMenuFrame:Hide() -- Initially hide the menu

-- Set a solid black background color for the menu
myMenuFrame:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
myMenuFrame:SetBackdropColor(0, 0, 0, .5)

-- Position the menu relative to the cursor
local function UpdateMenuPosition()
    local x, y = GetCursorPosition()
    myMenuFrame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x, y) -- Adjust the position as needed
end

-- Create a font string for the text above the buttons
local nameRealmEditBox = CreateFrame("EditBox", nil, myMenuFrame, "InputBoxTemplate")
nameRealmEditBox:SetPoint("TOP", myMenuFrame, "TOP", 0, -5) -- Position the text above the buttons
nameRealmEditBox:SetSize(100, 20)
nameRealmEditBox:SetAutoFocus(false)  -- Disable auto-focus
nameRealmEditBox:SetScript("OnEnterPressed", function(self) nameRealmEditBox:ClearFocus() end)  -- Clear focus on Enter
nameRealmEditBox:SetScript("OnEscapePressed", function(self) nameRealmEditBox:ClearFocus() end)  -- Clear focus on Escape

-- Create a font string for the text above the buttons
local statusText = myMenuFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
statusText:SetPoint("TOP", myMenuFrame, "TOP", 0, -30) -- Position the text above the buttons

-- Create a font string for the text above the buttons
local statusText = myMenuFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
statusText:SetPoint("TOP", myMenuFrame, "TOP", 0, -30) -- Position the text above the buttons

-- Create buttons for the menu options
local button1 = CreateFrame("Button", nil, myMenuFrame, "UIPanelButtonTemplate")
button1:SetPoint("TOPLEFT", 18, -45)
button1:SetSize(100, 20)
button1:SetText("Silent Warn")

local button2 = CreateFrame("Button", nil, myMenuFrame, "UIPanelButtonTemplate")
button2:SetPoint("TOPLEFT", 18, -65)
button2:SetSize(100, 20)
button2:SetText("Normal Warn")

local button3 = CreateFrame("Button", nil, myMenuFrame, "UIPanelButtonTemplate")
button3:SetPoint("TOPLEFT", 18, -85)
button3:SetSize(100, 20)
button3:SetText("Loud Warn")

local button4 = CreateFrame("Button", nil, myMenuFrame, "UIPanelButtonTemplate")
button4:SetPoint("TOPLEFT", 18, -105)
button4:SetSize(100, 20)
button4:SetText("Add to BList")

local button5 = CreateFrame("Button", nil, myMenuFrame, "UIPanelButtonTemplate")
button5:SetPoint("TOPLEFT", 18, -125)
button5:SetSize(100, 20)
button5:SetText("Kick Player")

-- Set an OnClick handler for button1
button1:SetScript("OnClick", function(self)
    SendChatMessage(">>RaidTools: " .. fullName .. " be careful what you do we don't accept the following; Ninja looting (Needing on gear the same or lower upgrade stage), Abusing (Swearing and/or Trolling), Failing to do mechanics or something after being asked, next time WILL result in you being REPLACED.", "WHISPER", nil, fullName)
end)

-- Set an OnClick handler for button2
button2:SetScript("OnClick", function(self)
    SendChatMessage(">>RaidTools: " .. fullName .. " be careful what you do we don't accept the following; Ninja looting (Needing on gear the same or lower upgrade stage), Abusing (Swearing and/or Trolling), Failing to do mechanics or something after being asked, next time WILL result in you being REPLACED.", "RAID")
end)

-- Set an OnClick handler for button3
button3:SetScript("OnClick", function(self)
    SendChatMessage(">>RaidTools: " .. fullName .. " be careful what you do we don't accept the following; Ninja looting (Needing on gear the same or lower upgrade stage), Abusing (Swearing and/or Trolling), Failing to do mechanics or something after being asked, next time WILL result in you being REPLACED.", "RAID_WARNING")
end)

local function OnPlayerLogin()
    -- Iterate the player list and show how many are loaded
    -- Count the number of items in the player list
    local count = 0
    for _ in pairs(BList) do
        count = count + 1
    end
    -- Print message to show addon has loaded
    print(">>RaidTools: Player Module Loaded with " .. count .. " players.")
    local fullName = ""
    local memberfullName = ""
    updatePlayerList()
end

-- This function is called when a new unit is targeted
local function OnPlayerTargetChanged()
    if not InCombatLockdown() then
        if UnitIsPlayer("target") and IsShiftKeyDown() then
            UpdateMenuPosition()
            local name, realm = UnitName("target")
            if realm == nil then
                realm = GetRealmName()
            end
            fullName = name .. "-" .. realm
            nameRealmEditBox:SetText(fullName) -- Update the text with the player's name
            if _G.BList[fullName] then
                statusText:SetText("!Bad!")
                button4:SetText("Remove from BList")
                button4:SetScript("OnClick", function(self)
                    _G.BList[fullName] = nil
                    print(">>RaidTools: " .. fullName .. " removed from the list.")
                    saveBList()
                    OnPlayerTargetChanged()
                end)
                button5:SetScript("OnClick", function(self)
                    SendChatMessage(">>RaidTools: " .. fullName .. ", sorry but you are already on our/my Raid Tools Addon BList, you are probably on this list for one of these reasons; Ninja looting (Needing on gear the same or lower upgrade stage), Abusing (Swearing and/or Trolling), Failing to do mechanics or something after being asked.", "RAID_WARNING")
                end)
            else
                statusText:SetText("Fine")
                button4:SetText("Add to BList")
                button4:SetScript("OnClick", function(self)
                    _G.BList[fullName] = true
                    print(">>RaidTools: " .. fullName .. " added to the list.")
                    saveBList()
                    OnPlayerTargetChanged()
                end)
                button5:SetScript("OnClick", function(self)
                    _G.BList[fullName] = true
                    print(">>RaidTools: " .. fullName .. " added to the list.")
                    saveBList()
                    OnPlayerTargetChanged()
                    SendChatMessage(">>RaidTools: " .. fullName .. " was just kicked for the one of these reasons; Ninja looting (Needing on gear the same or lower upgrade stage), Abusing (Swearing and/or Trolling), Failing to do mechanics or something after being asked. Perhaps next time they won't but there won't be a next time as they are now on my/our Raid Tools Addon BList.", "RAID_WARNING")
                end)
            end
            myMenuFrame:Show() -- Show the menu when a player is targeted and Shift is held
        else
            myMenuFrame:Hide() -- Hide the menu otherwise
        end
    else
        myMenuFrame:Hide() -- Hide the menu during combat lockdown
    end
end

local function OnGroupRosterUpdate()
    for i = 1, GetNumGroupMembers() do
        local memberName, memberRealm = UnitName("raid" .. i)
        if memberRealm == nil then
            memberRealm = GetRealmName()
        end
        memberfullName = memberName .. "-" .. memberRealm
        if _G.BList[memberfullName] then
            local playerBListWarn = ">>RaidTools: " .. memberfullName .. " is on your Raid Tools BList."
            print(playerBListWarn)
            RaidNotice_AddMessage(RaidWarningFrame, playerBListWarn, ChatTypeInfo["RAID_WARNING"])
        end
    end
end

local function OnPlayerLogout()
    saveBList()
end

-- Register the PLAYER_TARGET_CHANGED event
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("GROUP_ROSTER_UPDATE")
frame:RegisterEvent("PLAYER_LOGOUT")
frame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        OnPlayerLogin()
    elseif event == "PLAYER_TARGET_CHANGED" then
        OnPlayerTargetChanged()
    elseif event == "GROUP_ROSTER_UPDATE" then
        OnGroupRosterUpdate()
    elseif event == "PLAYER_LOGOUT" then
        OnPlayerLogout()
    end
end)