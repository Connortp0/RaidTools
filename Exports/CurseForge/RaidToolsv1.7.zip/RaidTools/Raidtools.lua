print(">>RaidTools: Loaded")
BList = _G.BList or {}

function saveBList()
    _G.BList = BList
    updatePlayerList()
end