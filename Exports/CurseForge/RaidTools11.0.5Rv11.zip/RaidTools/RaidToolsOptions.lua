-- RaidToolsOptions.lua

-- Create an options panel
local optionsPanel = CreateFrame("Frame", "RaidToolsOptionsPanel", InterfaceOptionsFramePanelContainer)
optionsPanel.name = "RaidTools"

-- Create a title for the panel
local title = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", 16, -16)
title:SetText("RaidTools " .. C_AddOns.GetAddOnMetadata("RaidTools", "Version"))

-- List Section
local listSection = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
listSection:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -20)
listSection:SetText("List")

local playerList = {}

-- Create a scrollable frame to display player names and realms
local scrollFrame = CreateFrame("ScrollFrame", "PlayerListScrollFrame", optionsPanel, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", listSection, "BOTTOMLEFT", 0, -10)
scrollFrame:SetSize(400, 150)

local scrollChild = CreateFrame("Frame", nil, scrollFrame)
scrollChild:SetSize(200, #playerList * 20) -- Adjust height based on the number of players

-- Display the total count
local totalCountLabel = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
totalCountLabel:SetPoint("TOPLEFT", scrollFrame, "BOTTOMLEFT", 0, -10)
totalCountLabel:SetText("Total Players: " .. #playerList)

-- Create a table to store the labels and buttons
local playerLabels = {}
local removeButtons = {}

function updatePlayerList()
    -- Clear the current player list
    playerList = {}

    -- Populate the player list from BList
    for playerNameRealm, _ in pairs(_G.BList) do
        local name, realm = string.match(playerNameRealm, "(.*)-(.*)")
        table.insert(playerList, {name = name, realm = realm, fullName = playerNameRealm})
    end

    -- Update the scroll child size based on the new player list
    scrollChild:SetSize(200, #playerList * 20)

    -- Remove the current labels and buttons in the scroll child
    for i, label in ipairs(playerLabels) do
        label:Hide()
        label:SetParent(nil)
        label:ClearAllPoints() -- Clear all anchor points
        removeButtons[i]:Hide()
        removeButtons[i]:SetParent(nil)
        removeButtons[i]:ClearAllPoints() -- Clear all anchor points
        removeButtons[i]:UnregisterAllEvents() -- Unregister all events
        removeButtons[i]:SetScript("OnUpdate", nil) -- Clear OnUpdate script
        removeButtons[i]:SetScript("OnClick", nil) -- Clear OnClick script
        removeButtons[i]:EnableMouse(false) -- Disable mouse
        removeButtons[i]:EnableKeyboard(false) -- Disable keyboard
    end

    -- Clear the tables
    playerLabels = {}
    removeButtons = {}

    -- Create labels and buttons for each player
    for i, playerData in ipairs(playerList) do
        local playerLabel = scrollChild:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        playerLabel:SetPoint("TOPLEFT", 10, -20 * (i - 1))
        if playerData.realm then
            playerLabel:SetText(playerData.name .. "-" .. playerData.realm)
        else
            playerLabel:SetText(playerData.name)
        end
        playerLabel:Show()  -- Make sure the label is visible

        -- Store the label
        table.insert(playerLabels, playerLabel)

        -- Create a remove button for each player
        local buttonRemove = CreateFrame("Button", nil, scrollChild, "UIPanelButtonTemplate")
        buttonRemove:SetPoint("TOPLEFT", playerLabel, "TOPRIGHT", 10, 0)
        buttonRemove:SetSize(100, 20)
        buttonRemove:SetText("Remove")
        buttonRemove:SetScript("OnClick", function(self)
            if _G.BList[playerData.fullName] then
                _G.BList[playerData.fullName] = nil
                print(">>RaidTools: " .. playerData.fullName .. " removed from the list.")
                saveBList()
            else
                print(">>RaidTools: " .. playerData.fullName .. " is not in the list.")
            end
        end)
        buttonRemove:Show()  -- Make sure the button is visible

        -- Store the button
        table.insert(removeButtons, buttonRemove)
    end

    -- Update the total count label
    totalCountLabel:SetText("Total Players: " .. #playerList)
end

scrollFrame:SetScrollChild(scrollChild)

-- Input box for player name-realm
local playerNameRealmInput = CreateFrame("EditBox", nil, optionsPanel, "InputBoxTemplate")
playerNameRealmInput:SetPoint("TOPLEFT", totalCountLabel, "BOTTOMLEFT", 0, -10)
playerNameRealmInput:SetSize(200, 20)
playerNameRealmInput:SetAutoFocus(false)  -- Disable auto-focus
playerNameRealmInput:SetScript("OnEnterPressed", function(self) playerNameRealmInput:ClearFocus() end)  -- Clear focus on Enter
playerNameRealmInput:SetScript("OnEscapePressed", function(self) playerNameRealmInput:ClearFocus() end)  -- Clear focus on Escape

-- Add Player button
local buttonAdd = CreateFrame("Button", nil, optionsPanel, "UIPanelButtonTemplate")
buttonAdd:SetPoint("TOPLEFT", playerNameRealmInput, "BOTTOMLEFT", 0, -10)
buttonAdd:SetSize(100, 20)
buttonAdd:SetText("Add Player")

buttonAdd:SetScript("OnClick", function(self)
    local playerNameRealm = playerNameRealmInput:GetText()
    -- Check if the input is in the format name-realm
    local name, realm = string.match(playerNameRealm, "(.*)-(.*)")
    if name and realm then
        if not _G.BList[playerNameRealm] then
            _G.BList[playerNameRealm] = true
            print(">>RaidTools: " .. playerNameRealm .. " added to the list.")
            saveBList()
        else
            print(">>RaidTools: " .. playerNameRealm .. " is already in the list.")
        end
    else
        print("Please enter a Name-Realm.")
    end
    playerNameRealmInput:SetText("")  -- Clear the input box
end)

-- Register the options panel
local category = Settings.RegisterCanvasLayoutCategory(optionsPanel, "RaidTools")
Settings.RegisterAddOnCategory(category)