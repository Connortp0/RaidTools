-- RaidToolsOptions.lua

-- Create an options panel
local optionsPanel = CreateFrame("Frame", "RaidToolsOptionsPanel", InterfaceOptionsFramePanelContainer)
optionsPanel.name = "RaidTools"

-- Create a title for the panel
local title = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", 16, -16)
title:SetText("RaidTools")

-- List Section
local listSection = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
listSection:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -20)
listSection:SetText("List")

local playerList = {}
for playerNameRealm, _ in pairs(PlayerList) do
    local name, realm = string.match(playerNameRealm, "(.*)-(.*)")
    table.insert(playerList, {name = name, realm = realm})
end

-- Create a scrollable frame to display player names and realms
local scrollFrame = CreateFrame("ScrollFrame", "PlayerListScrollFrame", optionsPanel, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", listSection, "BOTTOMLEFT", 0, -10)
scrollFrame:SetSize(200, 150)

local scrollChild = CreateFrame("Frame", nil, scrollFrame)
scrollChild:SetSize(200, #playerList * 20) -- Adjust height based on the number of players

-- Create labels for each player
for i, playerData in ipairs(playerList) do
    local playerLabel = scrollChild:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    playerLabel:SetPoint("TOPLEFT", 10, -20 * (i - 1))
    playerLabel:SetText(playerData.name .. "-" .. playerData.realm)
end

scrollFrame:SetScrollChild(scrollChild)

-- Display the total count
local totalCountLabel = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
totalCountLabel:SetPoint("TOPLEFT", scrollFrame, "BOTTOMLEFT", 0, -10)
totalCountLabel:SetText("Total Players: " .. #playerList)

-- About Section
local aboutSection = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
aboutSection:SetPoint("TOPLEFT", totalCountLabel, "BOTTOMLEFT", 0, -20)
aboutSection:SetText("About")


-- Display game version
local gameVersion = "10.2.6" -- Replace with addon's game version
local gameVersionText = "Game Version: " .. gameVersion
local gameVersionLabel = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
gameVersionLabel:SetPoint("TOPLEFT", aboutSection, "BOTTOMLEFT", 0, -10)
gameVersionLabel:SetText(gameVersionText)

-- Display addon version
local addonVersion = "v1" -- Replace with addon's version
local addonVersionText = "Addon Version: " .. addonVersion
local addonVersionLabel = optionsPanel:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
addonVersionLabel:SetPoint("TOPLEFT", gameVersionLabel, "BOTTOMLEFT", 0, -10)
addonVersionLabel:SetText(addonVersionText)

-- Register the options panel
InterfaceOptions_AddCategory(optionsPanel)
